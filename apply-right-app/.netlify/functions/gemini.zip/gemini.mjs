
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/gemini.mts
var GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent";
var json = (status, body) => new Response(JSON.stringify(body), {
  status,
  headers: { "Content-Type": "application/json" }
});
var gemini_default = async (req) => {
  if (req.method !== "POST") {
    return json(405, { error: { message: "Method not allowed" } });
  }
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return json(500, {
      error: { message: "Server is missing GEMINI_API_KEY configuration" }
    });
  }
  let payload;
  try {
    payload = await req.json();
  } catch {
    return json(400, { error: { message: "Invalid JSON request body" } });
  }
  try {
    const upstream = await fetch(`${GEMINI_URL}?key=${apiKey}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: payload.contents,
        generationConfig: payload.generationConfig
      })
    });
    const text = await upstream.text();
    return new Response(text, {
      status: upstream.status,
      headers: { "Content-Type": "application/json" }
    });
  } catch (err) {
    return json(502, {
      error: {
        message: err instanceof Error ? err.message : "Failed to reach Gemini API"
      }
    });
  }
};
export {
  gemini_default as default
};
